﻿#include <iostream>
#include "Engine.h"

int main()
{
    Engine engine;
    engine.Init();
    engine.Update();

    return 0;
}
